Name: Mrs. Robot
Value: 461
Description: As a high schooler, I went through a lot of interests. I was interested in many things: painting, writing, and video editing. However, my favorite extra-curricular had to be robotics, but I kinda forgot the team number my team was assigned...can you help?

FLAG FORMAT: `RUSEC{[team_number]}`
