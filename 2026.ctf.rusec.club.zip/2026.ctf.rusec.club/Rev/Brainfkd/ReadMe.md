Name: Brainf**kd
Value: 477
Description: Every CTF needs a classic flag-checker REV challenge with an esolang.

Have fun :)
