Name: Miss-Input
Value: 477
Description: *"IT'S A MISINPUT! YOU CALM DOWN! YOU CALM THE F*** DOWN!"*

[https://missinput.ctf.rusec.club](https://missinput.ctf.rusec.club)
