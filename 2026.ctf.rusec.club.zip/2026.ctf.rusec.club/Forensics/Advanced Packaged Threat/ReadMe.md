Name: Advanced Packaged Threat
Value: 467
Description: Earlier on in the year I used a custom PPA for a long-discontinued library I needed in my experimental program. I ended up not using it, but soon forgot about it later on. However, this morning, I went to check back in on my server and discovered a strange SSH public key in my root SSH user.

I have a packet capture from yesterday detailing everything happening on the network. Could you maybe take a look at it?

[intercept.pcapng](https://drive.google.com/file/d/1kMwfQtC9NqdnTVPvCwy3d5vXJTexh3Qu/view?usp=sharing)
