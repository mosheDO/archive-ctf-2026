Name: Feedback
Value: 8
Description: As the CTF wraps up and you all do the challenges **WE** made, now it's time for **YOU** to make something!

Specifically, we want your feedback at [the official Scarlet CTF feedback form](https://forms.gle/PagjHotHbYBVzkrF8)!
