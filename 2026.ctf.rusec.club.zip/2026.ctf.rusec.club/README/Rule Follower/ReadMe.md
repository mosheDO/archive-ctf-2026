Name: Rule Follower
Value: 10
Description: Welcome to **Scarlet CTF**!

This should be pretty easy for your first flag! All you gotta do is just make sure you read the rules :)

`nc challs.ctf.rusec.club 62075`
