Name: Amels (Level0)
Value: 494
Description: Haii!! I need your help! `>_>`

There's this microcelebrity girlypop game developer called [Amels](https://amels.itch.io/) I'm really fond of. I've been following her work **EXTENSIVELY!** on her social media!! (Call me a big fan)

(She hates alot of common social medias like Instagram, Twitter, etc., so it was really hard to find it `>_<`)

However, there's this new game that I really, **REALLY** want to play!! I've heard, from what she's been saying, that it's called `SpaceTime`, but I can't seem to find it anywhere! I'm not that much of an OSINT GOD like u seem to be, could u maybe help me figure it out? :c

Can you find the listing of the game and gain access to it? Pweeese!! I neeed to play it :(
