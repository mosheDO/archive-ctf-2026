Name: kAnticheat (Level4)
Value: 494
Description: **NOTE:** This challenge is unrelated to the previous levels of **MelStudios**. You do not need to solve previous challenges in order to solve this one.

This is supes big!!

Turns out this silly little game dev is becoming a **KERNEL** dev?? People have been saying some crazy things!! Apparentyl she's making her own kernel level anticheat?? And it's WIP???

You need to get to the bottom of this. I managed to sneak out some files (hehe phishing ^-^ phishy). Can you see if it's vulnerable? She's running it on her home network, so maybe if we can PWN HER SYSTEM we can leak all her SUPER SECRET VIDEO GAMES!!1! (i'll be RICHHHHH)

Tank u!!! You're the best!!! :D

`nc challs.ctf.rusec.club 47095`

[Participant Files](https://drive.google.com/drive/folders/1m_fkSZ2fdBD6D_KddGGYB5-5T9-L4D-E?usp=sharing)
