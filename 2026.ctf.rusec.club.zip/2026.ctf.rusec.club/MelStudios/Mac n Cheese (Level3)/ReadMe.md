Name: Mac n' Cheese (Level3)
Value: 496
Description: A wittle birdy once told meh that Amels was really *really* scared about something regarding authentication :O

She responded saying that there's a critical flaw in authentication that *could* be VERYY bad!!! It was something about the vulnerabilites of "CBC-MAC" and how she wanted to try "another mode"? Something with "feedback" in the name. I'm not a hacker 🤓 emoji like u so I have no clue what that means, but figured it might be important...

I also saw on stream that she was playing with an account called `amels_gamedev_123X`, the X is a number that i couldn't quite catch (so u might need to bruteforce for it) :c

Can u maybe exploit this >:3

(Maybe u can get into her accoujnt!!)
