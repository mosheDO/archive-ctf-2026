Name: Coloring Fraud
Value: 458
Description: Now give it a try from the other side...

`nc challs.ctf.rusec.club 2752`
