Name: ruid_login
Value: 460
Description: Take a look at this super l33t login system I made for my Computer Architecture class! Heh...my prof is gonna be so proud. He's 100% gonna boost my GPA.

Surely this will be safe to push to prod. I'll even do it for him!

`nc challs.ctf.rusec.club 4622`
