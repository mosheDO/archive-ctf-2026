Name: speedjournal
Value: 145
Description: Its 2026, I need to start journal-maxing. Thats why I use speedjournal, which lets me brain-max my thoughts while time-maxing with the speed of C! Its also security-maxed so only I can read my private entries!

`nc challs.ctf.rusec.club 22169`
