Name: Forge's ....... well forge
Value: 0
Description: Forge has made it so that only his trinket can open his workshop(forge) or so it would seem.

> Author : shura356
