Name: Tick Tock
Value: 0
Description: Our engineers are obsessed with performance.Their main goal? **Speed.**

To keep things fast, the password verification service avoids doing more work than necessary.  
Every millisecond counts.

Correct password gives the flag

The password consists only of digits:
0-9
Can you recover it?

`nc chals3.apoorvctf.xyz 9001`
