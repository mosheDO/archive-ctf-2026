Name: The Domino Effect
Value: 0
Description: The message uses a verification which only domino is supposed to be able to solve

`nc chals2.apoorvctf.xyz 13337`

> Author : shura356
