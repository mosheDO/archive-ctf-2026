Name: Cable's Temporal Loop
Value: 0
Description: Whenever Nathan Summers solves one of the stages with his time jump machine, the next stage changes up on him.

`nc chals2.apoorvctf.xyz 13424`

> Author : shura356 & fl4nk3r
