Name: Riddler's Respite
Value: 0
Description: After being foiled twice and having his crypto puzzles decrypted, the Riddler felt defeated and decided to switch to algorithms and mathematics -- he'll surely get you this time, or so he thinks!

`nc chals1.apoorvctf.xyz 13001`

> Author : accord
