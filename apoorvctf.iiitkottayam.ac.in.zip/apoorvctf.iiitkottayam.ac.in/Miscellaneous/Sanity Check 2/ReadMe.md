Name: Sanity Check 2
Value: 0
Description: Well you have joined our discord server right? Happy hunting.
I made this challenge so this challenge is more of an insanity check, and not expected to have high number of solves, but if somehow it gets high solves the flag is what i have to say

> Author : makeki
