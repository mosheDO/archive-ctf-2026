Name: Welcome
Value: 0
Description: Welcome to **ApoorvCTF'26**. 

Did you join our discord? https://discord.gg/jUg8JNyX
