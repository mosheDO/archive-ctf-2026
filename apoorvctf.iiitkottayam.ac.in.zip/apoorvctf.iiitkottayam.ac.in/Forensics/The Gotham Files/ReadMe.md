Name: The Gotham Files
Value: 0
Description: A mysterious panel surfaced at this year's ComiCon. The artist left something behind.

> Author : n3twraith
