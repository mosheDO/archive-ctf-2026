Name: Coloring Heist
Value: 376
Description: Do you know about zero knowledge proofs? What about graph coloring? What about a graph coloring zero knowledge proof?

`nc challs.ctf.rusec.club 2751`
