Name: Peculiar Code (Level1)
Value: 496
Description: WAOW!! Looks like we finally found the game!!!1 :D

Are you able to take a look at it??? I have a hunch that it might be doing something realllly weird but I don't know and I can't prove it :c
