Name: Revenge (Level5)
Value: 495
Description: So, apparently there was something up with the emulator...? :0

Turns out, she fixed it. Something with an escape character. Whatever, she fixed it now.

`nc challs.ctf.rusec.club 3441`

(Use the same files as `Melstudios Level4`)
