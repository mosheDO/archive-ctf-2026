Name: Brainf**kd
Value: 486
Description: Every CTF needs a classic flag-checker REV challenge with an esolang.

Have fun :)
