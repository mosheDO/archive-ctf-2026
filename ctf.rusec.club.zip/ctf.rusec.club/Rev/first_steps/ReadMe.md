Name: first_steps
Value: 100
Description: Find the flag hidden in the binary!
