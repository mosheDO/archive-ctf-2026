Name: court_jester
Value: 429
Description: I reside as the Queen of this data kingdom. Prithee, I implore you to remedy the ailments of our poor beloved court jester. In the days since he imbibed an entire cask of old mead I suspect was fermented from a bad batch of barley microkernels, he has not been himself and, well, juggles data all wrong! Help us I plead, our kingdom depends on YOU, traveller!
