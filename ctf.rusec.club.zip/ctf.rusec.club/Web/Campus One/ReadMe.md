Name: Campus One
Value: 460
Description: Welcome to **CampusOne** - your one-stop shop for all your college tech needs!

We just launched our new e-commerce platform for Rutgers students. Our developers assure us it's completely secure, but we've been getting some strange reports about unauthorized admin access...

Can you find a way to access the admin panel and uncover what's hidden there?

[https://campus-one.ctf.rusec.club](https://campus-one.ctf.rusec.club)
