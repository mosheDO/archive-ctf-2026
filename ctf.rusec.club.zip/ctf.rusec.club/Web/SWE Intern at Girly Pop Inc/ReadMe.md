Name: SWE Intern at Girly Pop Inc
Value: 406
Description: Last week we fired an intern at Girlie Pop INC for stealing too much food from the office. It seems they didn't know much about secure software development either...

**NOTE:** This challenge allows the usage of a specific type of automated type of tool; you will know when you see it.

[https://girly.ctf.rusec.club](https://girly.ctf.rusec.club)
