Name: Mole in the Wall
Value: 487
Description: We just launched our new parent development company, Girlie Pop's Pizza Place! Packed with your favorite animatronics, we hold pizza parties and games galore! Sometimes Bonita the Yellow Rabbit has been acting a bit out of line recently however...

**Hint:** The animatronics get a bit quirky at night. They tend to get their security from a JSON in debug/config...

[https://girlypies.ctf.rusec.club](https://girlypies.ctf.rusec.club)
