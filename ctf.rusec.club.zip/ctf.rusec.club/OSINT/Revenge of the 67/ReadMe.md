Name: Revenge of the 67
Value: 489
Description: Oh great heavens! Help me!

I was in a battle fighting with my comrades when all of a sudden, during my fight, I was struck in the back with a pistol round and lost conciousness. I need to be let out soon..otherwise, I fear I may die in here.

I need you to find something for me. I overheard one of the guards talk about how their leader tried to make a web exploitation challenge for **this very CTF**. They ultimately didn't have much time to finish, so asked the admins to take down the portions of their infrastructure relating to his challenge, along with all related records (entries to IPs, aliases, etc). The issue, though, is that because of how last-minute this was, they might not have deleted *everything*. They're saying there might still be entries relating to non-infrastructure things, but what could those possibly be?

Maybe take a look at other web challenges and how to connect to them...there might be a pattern here...

Also, look for things that are their name but lowercase, with all honoraries removed. For example, if his name is `King Ben Swolo`, look for `ben_swolo`.

My signal's almost dead, so I fear I'll be waiting for you, friend. Good luck.
