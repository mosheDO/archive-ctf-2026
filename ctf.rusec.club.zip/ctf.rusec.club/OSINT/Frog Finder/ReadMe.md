Name: Frog Finder
Value: 494
Description: A certain amphibian has shown up in the ScarletCTF Discord. They have declared that if you can tell him his name, and how much wealth he has, the flag is yours.

**Disclaimer:** This challenge does not require you to send a message or target an actual person and their personal details. Animals cant use the internet, right?

FLAG FORMAT: `RUSEC{NAME_MONEY}`.

For Example, if you find a name "John Doe" with 6767 wealth, your flag is `RUSEC{JOHNDOE_6767}`
