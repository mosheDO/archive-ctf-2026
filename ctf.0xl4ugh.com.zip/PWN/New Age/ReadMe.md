Name: New Age
Value: 0
Description: They said a carefully crafted seccomp filter would always save you, can you make sure for me?

**Author**: `Ziad`
