Name: Zoro’s Blind Path
Value: 0
Description: The only way forward is understanding what cannot be seen

**Author**: `0xStrawHat`
