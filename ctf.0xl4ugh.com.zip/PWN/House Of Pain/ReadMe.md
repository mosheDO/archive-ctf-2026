Name: House Of Pain
Value: 0
Description: This house is welcoming.
The journey, however, can be painful.

**Author**: ThePainTester
