Name: Delicious Meeting
Value: 0
Description: Willow1124 is planning to meet Ken to enjoy their favorite food. The uploaded files include a picture of Willow1124’s hometown. Use Google Maps at all times.


Your task is to figure out the email address of the place where they met.

```
Flag Format: 0xL4ugh{0xL4ugh@gmail.com}
```

**Author**: `Zwique`
