Name: Dune
Value: 0
Description:   ⁣I‌n‍ ⁣t⁣h​e​ ‌w⁤o‌r⁢l﻿d﻿ ⁢o​f​ ‌D⁠u‌n⁠e⁣,⁣ ⁤e‍v​e⁣r⁤y⁠t‌h​i﻿n⁢g‌ ‌h⁣a‌s﻿ ​t⁢w‍o​ ⁤f﻿a‌c‍e⁢s⁣ ⁣d​e﻿p​e﻿n‌d‌i⁤n⁠g⁢ ﻿o⁢n‌ ​w​h⁤o⁣ ⁢y⁢o⁢u⁢ ⁤a⁤r​e⁢.‍
  ⁠A⁣ ⁢F⁣r⁤e⁠m⁣e⁠n‍ ‍c⁣a‍n⁢ ⁢b⁣e﻿ ﻿a⁠ ⁣t​r⁤u‌s‌t⁢e⁣d​ ‌a﻿l‍l﻿y​ ​t⁤o‌ ​H​o‌u﻿s﻿e⁤ ‌A‌t‌r​e​i﻿d‍e⁣s﻿…​ ⁤o⁣r⁣ ⁣a﻿ ﻿n⁤i‌g⁢h⁢t⁤m‍a⁢r‌e‌ ﻿t⁤o⁠ ​H⁣o⁣u⁠s﻿e​ Harkonnen.
  
In the last cycles, our largest automation colony, Arrakis-colony, was hit by a so-called Sand Worm.
The harvesters stalled, telemetry went wild and, worst of all, Secrets were stolen.
  
Your mission is to help us understand what really happened – and recover what was taken.
  
Find our official Presence on the Open Web.
  
From there, track down where we keep our harvesters’ Source Code.
Somewhere in those spice Packages you will see what the sand beast did to us.
  
Rumours say that someone has already seen a piece of our secrets and left traces of it behind.
We need you to confirm or deny this, and follow the trail as it moves across dunes.
  
Be aware of the Many Fakes, If you read the signs correctly and follow every breadcrumb, you’ll uncover all stolen fragments.
	
```
Flag format: 0xL4ugh{part1_part2_part3} 
```
	(no spaces).

**Author**: `0xOsama`
