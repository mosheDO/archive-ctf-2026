Name: Clowns APT
Value: 0
Description: Hello agent 73 You have a new mission.
We have a victim to some kind of attacks, but we aren't sure about the full impact until now.
This is the message we received from the victim:

"Hi, I’m a beginner nodeJS backend developer. I was practicing my skills on developing a random project.
After I finished my work I didn’t find my work (seems to be deleted) and found this strange **image** (attached below), am i really hacked ?!!"

You only have this image, Agent 73. Do your job.


**Author**: `0xk4k45h1`, `Mushroom`
