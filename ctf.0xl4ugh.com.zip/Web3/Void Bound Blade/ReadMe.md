Name: Void Bound Blade
Value: 0
Description: In the depths of the Voidbound Shrine, an ancient evil stirs. The Void Shogun a being of unfathomable power with 1,000,000,000,000 HP guards the sanctum, waiting to strike down any who dare challenge its reign. You are a wanderer, drawn to this cursed place. But the gates are sealed to outsiders. The shrine's mystic barriers woven by dark katas and protected by otherworldly torii gates refuse your entry. To defeat the Shogun, you must first prove yourself worthy.
 
 ---
 
 **Author** : 0xAnan
