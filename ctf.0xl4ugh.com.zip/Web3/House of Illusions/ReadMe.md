Name: House of Illusions
Value: 0
Description: Behind a velvet curtain sits the House of Illusions, a mirror proxy manor that rewrites what you think is real. You are admitted as a Visitor, but only a Curator may command the house. Find a path to claim the Curator role for your address.

 ---
 
 **Author** : 0xAnan
