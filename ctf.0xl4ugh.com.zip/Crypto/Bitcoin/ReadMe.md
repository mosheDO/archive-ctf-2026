Name: Bitcoin
Value: 0
Description: The Zwique holds the master key. He'll offer a quick demonstration using something. Help me to steal his flag.

---
**Author** : Zwique
