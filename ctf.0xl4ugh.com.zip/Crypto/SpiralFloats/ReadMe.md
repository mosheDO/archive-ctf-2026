Name: SpiralFloats
Value: 0
Description: A flag was turned into a real number, pushed through a spiral, then partially erased.

Dumb brute won’t cut it.

**Author**: `x3ric`
