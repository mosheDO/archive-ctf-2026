Name: DORYA
Value: 0
Description:   just like tekken, spamming the same move, i mean encryption, many times is unbeatable.

**Author**: `irena`
