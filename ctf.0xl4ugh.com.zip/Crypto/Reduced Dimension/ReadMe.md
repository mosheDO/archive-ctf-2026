Name: Reduced Dimension
Value: 0
Description:  I'm super bored of working on regular RSA. So, I implemented a 2022 optimization on it. Go ahead and check this out.
 
 **Author**: `Zwique`
