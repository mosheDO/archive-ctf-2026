Name: Awesome Router
Value: 0
Description: Trust me, if this challenge solved in the inteneded way, there is a lot of fun ; )

**Authors:** abdoghazy, Marco, W4lter, 0xStrawHat, Khaled and Zayat
