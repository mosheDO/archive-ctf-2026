Name: 12
Value: 0
Description: Do you know what **12** stands for in this challenge? Good luck figuring that out.

**Author**: `omr00t`
