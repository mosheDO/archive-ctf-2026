Name: UCalculator
Value: 0
Description: Qt for GUIs...? Nah, I’m using Unreal Engine.
    
Welcome to the first calculator app on UE.<br>

Totally normal, and it definitely doesn’t hide anything inside ;)
<br>

<a href=" https://drive.google.com/file/d/1nJfqZsmWvPYkbSgLDWrtDK9h7AOIuMAv/view?usp=drivesdk" style="color: red; text-decoration: underline;text-decoration-style: dotted;"    target="_blank">Download Challenge</a>
<br> 
<br> 
*Note: IDA might take some time to finish analyzing the entire binary, but it will eventually complete.*<br>

*However, waiting for it to finish is not mandatory to solve the challenge.*
<br>
<br>

**Author**: `ELJoOker`
