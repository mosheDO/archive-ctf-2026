Name: SCA1
Value: 0
Description: You are given some power traces and plaintexts for an AES encryption, get the secret.

Note: wrap the key in `0xL4ugh{}`
	
**Author**: `hegzploit`
