Name: SCA2
Value: 0
Description: SCA1 was easy? now try solving this :)

Note: wrap the key in `0xL4ugh{}`
	
**Author**: `hegzploit`
