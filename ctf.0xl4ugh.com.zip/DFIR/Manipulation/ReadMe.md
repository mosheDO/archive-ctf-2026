Name: Manipulation
Value: 0
Description: ALLAM was working on a project file when something weird happened—some numbers didn’t match up, and the data looked off. Turns out, someone accessed his machine, edited the file, and left without a trace. Your job? Dig through the disk image, track the changes, and figure out exactly what was altered to reveal the flag. <br>

**Password**: `a1l4m`
> **Author**:  `a1l4m`
