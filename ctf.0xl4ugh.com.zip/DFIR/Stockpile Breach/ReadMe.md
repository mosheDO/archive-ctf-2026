Name: Stockpile Breach
Value: 0
Description: The SOC team received an alert indicating suspicious command executions from an external IP targeting finance employee Khaled’s workstation. The commands appear to have been executed remotely, raising concerns of potential compromise. Initial threat intelligence links the IP to known malicious activities.
As a DFIR analyst, you have been provided with a triage image of Khaled’s machine for further investigation. Your objective is to analyze the image, identify indicators of compromise (IOCs), determine the attack vector, and assess the impact.
Key stakeholders, including IT security lead Sarah and finance director Ahmed, are awaiting your findings to coordinate response actions.

<a href="https://drive.google.com/file/d/1TXN57ypwAKsl7JQwHRN7N7-0H3_PCCtB/view?usp=drive_link" style="color: red; text-decoration: underline;text-decoration-style: dotted;"    target="_blank">Download Challenge</a>
<a href="https://mega.nz/file/UmEClYCS#V1aBOvC4xXTl3ahqsbReK4ZtPUCtpD_3KHJbGGa9sF8" style="color: red; text-decoration: underline;text-decoration-style: dotted;"    target="_blank">Mirror Link</a>
<br> 

Files Password:  **0xL4ugh@DFIR2026**
> **Author**: `a1l4m`
