Name: ismailia
Value: 0
Description: فكهاني وبحب المانجا

I'm a fruit seller and I love mango 🥭

- Challenge: 
						https://webctf.online/
- Bot:
						 http://143.110.133.50:1337/

🛑🛑 SOLVE IT LOCALLY FIRST 🛑🛑

Author: `Z4ki`
