Name: 4llD4y
Value: 0
Description: Stuck in the same day.

**Author**: `0xbla
