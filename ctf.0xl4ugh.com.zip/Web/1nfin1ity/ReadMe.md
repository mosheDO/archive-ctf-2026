Name: 1nfin1ity
Value: 0
Description: Can you see my note app version before I publish it !!

**Author**: `Zonkor`
