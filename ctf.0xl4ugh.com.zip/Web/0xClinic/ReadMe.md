Name: 0xClinic
Value: 0
Description: it's your first pentesting assessment, avoid showing any skill issues nget your flag by executing `cat /proc/*/environ`

https://en.wikipedia.org/wiki/Egyptian_National_Identity_Card

**Author**: `Kalawy`, `Zonkor`
