Name: 0xNote
Value: 0
Description: “Do you like note-taking? I think I know what your answer will be (˶˃ ᵕ ˂˶)”

**Author**: `winky`
