Name: Ghost Board
Value: 0
Description: 👻👻👻

**Author**: ShaDow
