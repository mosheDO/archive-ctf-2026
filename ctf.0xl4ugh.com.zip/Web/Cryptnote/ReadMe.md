Name: Cryptnote
Value: 0
Description: What about another burnt zeroday ?  : P

[Cryptnote](https://cryptnote.webctf.online/) <br>
[Sandbox](https://sandbox.cryptnote.webctf.online/) <br>

**Author**: `0xbla` <br>
Spawn Bot instance:

