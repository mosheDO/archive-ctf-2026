Name: Smol Web
Value: 0
Description: My friend told me to block quotes to stop SQL injection, I followed their advice and it seems to be doing a great job stopping hackers. My secret is safe now.

**Author**: `Marco`
