Name: HashCashSlash
Value: 0
Description: Hash (#), Cash ($), and Slash (\\) - are these three characters enough to pwn? 

**Author**: `Mushroom`
