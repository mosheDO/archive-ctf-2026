Name: Spare Me Some Change
Value: 0
Description: Time travel is beutiful, can you make money out of it?


```bash
nc spare-change.webctf.online 1337
```


Author: `Mushroom`
