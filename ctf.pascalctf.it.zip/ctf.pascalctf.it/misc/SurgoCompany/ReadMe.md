Name: SurgoCompany
Value: 0
Description: **SurgoCompany™** has just launched a brand-new online Customer Service platform 🧩. The system is still under development, and you've been asked to test it 😈.
Simply enter your email, describe your issue, and optionally upload a file related to your problem 🤨.

The source code of the challenge is saved somewhere on the filesystem... and rumor has it that a file named *flag.txt* is hiding in that very same folder 😜.

Can you find a way to read it?

Email box: https://surgo.ctf.pascalctf.it <br>
Email account generator: https://surgoservice.ctf.pascalctf.it
