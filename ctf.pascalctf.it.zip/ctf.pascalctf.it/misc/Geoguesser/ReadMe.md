Name: Geoguesser
Value: 0
Description: Alan Spendaccione accumulated so much debts that he travelled far away to escape Fabio Mafioso, join the mafia and help Fabio catch Alan!

The flag format is `pascalCTF{YY.YY,XX.XX}` where Y=latitude and X=longitude, round the numbers down.
