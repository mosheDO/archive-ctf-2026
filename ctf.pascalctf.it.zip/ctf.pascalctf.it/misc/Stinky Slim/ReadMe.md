Name: Stinky Slim
Value: 0
Description: I don't trust Patapim; I think he is hiding something from me.
