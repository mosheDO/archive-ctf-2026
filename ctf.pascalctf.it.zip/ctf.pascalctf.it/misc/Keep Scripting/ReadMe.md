Name: Keep Scripting!
Value: 0
Description: I always loved bombare, but my friend Elia challenged me to finish this level in 1 minute! It's impossible!!!1!
