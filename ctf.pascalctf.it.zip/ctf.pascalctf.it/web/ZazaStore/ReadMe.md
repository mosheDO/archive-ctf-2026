Name: ZazaStore
Value: 0
Description: We dont take any responsibility in any damage that our product may cause to the user's health
