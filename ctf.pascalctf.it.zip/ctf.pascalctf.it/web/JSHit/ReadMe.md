Name: JSHit
Value: 0
Description: I hate Javascript sooo much, maybe I'll write a website in PHP next time🔥!
