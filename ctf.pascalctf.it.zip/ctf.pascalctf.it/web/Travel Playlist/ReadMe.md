Name: Travel Playlist
Value: 0
Description: ```
Nel mezzo del cammin di nostra vita
mi ritrovai per una selva oscura, 
ché la diritta via era smarrita.
```

The flag can be found here `/app/flag.txt`
