Name: StrangeVM
Value: 0
Description: A 🧙🏻‍♂️ stranger  once built a VM and hid the **Forbidden Key**🥀, can you uncover it?

**P.S.**: Keep all the files in the same directory for easier debugging and execution.
