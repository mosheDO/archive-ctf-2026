Name: AuraTester2000
Value: 0
Description: Will you be able to gain enogh aura?
