Name: Albo delle Eccellenze
Value: 0
Description: One of our former Blaisone CTF Team members 🚩 has just earned a medal in the Cyberchallenge.IT contest 🥳. 

He’s now wondering whether he also received a prize 🏆, could you help him find out?
