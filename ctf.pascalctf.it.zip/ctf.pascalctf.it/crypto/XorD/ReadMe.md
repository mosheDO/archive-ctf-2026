Name: XorD
Value: 0
Description: I just discovered bitwise operators, so I guess 1 XOR 1 = 1?
