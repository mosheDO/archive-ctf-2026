Name: wordy
Value: 0
Description: Bored in class? Try this cryptic Wordle twist and crack the next word! 🧩🔐
