Name: Ice Cramer
Value: 0
Description: Elia’s swamped with algebra but craving a new ice-cream flavor, help him crack these equations so he can trade books for a cone!
