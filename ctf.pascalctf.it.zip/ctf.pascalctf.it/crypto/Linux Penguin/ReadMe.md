Name: Linux Penguin
Value: 0
Description: I've just installed Arch Linux and I couldn't be any happier :)
