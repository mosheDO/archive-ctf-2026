Name: Curve Ball
Value: 0
Description: Our casino's new cryptographic gambling system uses elliptic curves for provably fair betting. 

We're so confident in our implementation that we even give you an oracle to verify points!
