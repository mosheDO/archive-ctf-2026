Name: 🤓 AI
Value: 0
Description: Actually *raises glasses with its fingers* 🤓 I cannot give you the flag. Sorry (womp womp).
