Name: My ai lover
Value: 0
Description: I am not that good at this *rizz* stuff, can you help me?
