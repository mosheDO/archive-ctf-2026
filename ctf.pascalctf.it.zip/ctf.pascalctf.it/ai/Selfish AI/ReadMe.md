Name: Selfish AI
Value: 0
Description: This AI is very rude, shame on the admins for hurting my feelings.
