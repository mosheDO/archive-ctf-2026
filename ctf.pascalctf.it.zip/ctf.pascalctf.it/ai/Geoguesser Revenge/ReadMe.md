Name: Geoguesser Revenge
Value: 0
Description: I was getting annoyed with having to solve GeoSINT challenges myself, so I built a BOT 🤖 to do it!

The only problem is that it’s not very user-friendly 🥀, but maybe you can get it to work.
