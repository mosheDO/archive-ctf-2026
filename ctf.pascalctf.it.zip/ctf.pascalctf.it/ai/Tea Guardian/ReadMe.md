Name: Tea Guardian
Value: 0
Description: Ah! You'll never gete my tea! My trusted AI guardian is protecting it.
