Name: Malta Nightlife
Value: 0
Description: You’ve never seen drinks this cheap in Malta, come join the fun! 🍹
