Name: Grande Inutile Tool
Value: 0
Description: Many friends of mine hate git, so I made a git-like tool for them.

The flag can be found at `/flag`.

You can get a user here: https://git-service.ctf.pascalctf.it
