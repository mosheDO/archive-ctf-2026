Name: YetAnotherNoteTaker
Value: 0
Description: I've read too many notes recently, I can't take it anymore...

