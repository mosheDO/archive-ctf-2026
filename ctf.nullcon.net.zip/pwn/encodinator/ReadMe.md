Name: encodinator
Value: 0
Description: I've written a small tool to do some encoding me for. Can you exploit it?

Author: @gehaxelt

