Name: hashchain
Value: 0
Description: They said MD5 was broken. They said it was insecure. But they never said it could run.

Author: @gehaxelt

