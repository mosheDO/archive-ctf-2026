Name: hashchain v2
Value: 0
Description: The easy path is gone.  Build your own path to victory.

Author: @gehaxelt

