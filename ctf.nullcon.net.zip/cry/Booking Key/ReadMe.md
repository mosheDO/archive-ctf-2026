Name: Booking Key
Value: 0
Description: Books have always been a beautiful place to hide information, sometimes in plain sight.
