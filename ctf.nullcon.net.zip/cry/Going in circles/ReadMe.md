Name: Going in circles
Value: 0
Description: Whenever I try to get the flag, I only get some checksum. I feel like I'm going in circles.
