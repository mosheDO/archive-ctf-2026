Name: Null Sanity
Value: 0
Description: Are you sane or not? 

ENO{welcome_to_nullcon_goa_ctf_2026!}
