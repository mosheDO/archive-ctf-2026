Name: Hashinator
Value: 0
Description: We've found this binary in an super old backup of a super old system. It outputs some hashes, but maybe there's more to it?

Author: @gehaxelt
