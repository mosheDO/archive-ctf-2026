Name: Coverup
Value: 0
Description: We've got the encrypted flag and some coverage information. Can you help us recover the flag?

Author: @gehaxelt
