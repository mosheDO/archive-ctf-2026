Name: Opalist
Value: 0
Description: We've got some weird output from a program written in a super obscure language. Can you help us recover the flag?

HINT: To solve the challenge you have to use the following flag format: ENO{DECODED OUTPUT}

Author: @gehaxelt
