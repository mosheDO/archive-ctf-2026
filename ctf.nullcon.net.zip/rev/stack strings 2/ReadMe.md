Name: stack strings 2
Value: 0
Description: Nothing to see here part 2
