Name: Flowt Theory 2
Value: 0
Description: My friends and I built the BillSplitter Lite app to track our expenses and settle debts. It uses some extremely advanced math to make sure everyone pays exactly what they owe...
Can you find the hidden administrative fee?

Author: Gaugerus
