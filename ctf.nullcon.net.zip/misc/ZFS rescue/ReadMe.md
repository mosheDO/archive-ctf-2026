Name: ZFS rescue
Value: 0
Description: We had all our flags on this super old thumb drive. My friend said the data would be safe due to ZFS, but here we are... Something got corrupted and we can only remember that the password was from the rockyou.txt file... 

Can you recover the flag.txt?

Author: @gehaxelt
