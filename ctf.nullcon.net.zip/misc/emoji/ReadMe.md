Name: emoji
Value: 0
Description: 
