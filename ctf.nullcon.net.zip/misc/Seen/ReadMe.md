Name: Seen
Value: 0
Description: Well this LOOKS like its an easy one :)
