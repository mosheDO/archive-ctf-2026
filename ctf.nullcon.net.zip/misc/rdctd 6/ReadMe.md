Name: rdctd 6
Value: 0
Description: Due to the German Freedom of Information Act (Informationsfreiheitsgesetz), we may be forced to publish some documents. 
To keep the fun in the game we redacted some information before publishing it.

There are 6 hidden flags in the file and therefore six challenges with the same pdf file. 
Submit here the flag containing a 6.
