Name: DiNoS
Value: 0
Description: Some flag escaped its enclousure. Now it is mixed up with the herd(dinos.nullcon.net). Can you spot it?

Verify you can visit the DiNoS:  dig @ip -p 5052 TXT "verify.enodns.nullcon.net"

Author: @vonDowntown
