Name: Zoney
Value: 0
Description: I heard you like DNS? Show me that you know all about it.
There might be a flag hidden for you somewhere: flag.ctf.nullcon.net

Port: 5054

Author: @gehaxelt
