Name: DragoNflieS
Value: 0
Description: Are you up to date about the latest and greatest DNS features? Now you don't need VPN and Firewalls anymore to ensure that only internal networks can resolve certain DNS names, such as flag.ctf.nullcon.net.

Try it yourself on port 5053

Author: vonDowntown & gehaxelt
