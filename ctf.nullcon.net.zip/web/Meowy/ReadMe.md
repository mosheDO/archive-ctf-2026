Name: Meowy
Value: 0
Description: My friends vibe-coded a cute cat image gallery plattform... but as we know, vibe coding leads to insecure applications... Do you manage to prove it to them by finding a flag somewhere on their web server?

Oh, they also showed me some source code, but their cat... meowed over it.

Author: @gehaxelt
