Name: WordPress Static Site Generator
Value: 0
Description: I wanted to convert my WordPress page into a static website, so I implemented a suitable tool... but can it protect /flag.txt?

Author: @gehaxelt
