Name: CVE DB
Value: 0
Description: Let's implement our own CVE database with modern web-scale technologies, so without actual SQL.

Author: @gehaxelt
