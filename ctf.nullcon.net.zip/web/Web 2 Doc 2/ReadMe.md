Name: Web 2 Doc 2
Value: 0
Description: This is the same service as Web2Doc v1, but this time we have removed the /admin/flag endpoint. Can you still gain access to the secret contents of /flag.txt?

Hint: You should solve Web2Doc v1 first.

Author: @gehaxelt
