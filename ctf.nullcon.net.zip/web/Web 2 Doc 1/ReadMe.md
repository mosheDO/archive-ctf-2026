Name: Web 2 Doc 1
Value: 0
Description: We needed an easy way to turn websites into PDF documents, so we implemented a simple flask app for that. Luckily, there are easy librarieres to do the hard work of print ing a website into a PDF...

There's one particular endpoint we wanted to protect, so I'm providing you only that one function. The rest isn't as interesting anyway...

Author: @gehaxelt
