Name: virus analyzer
Value: 0
Description: I wrote my own virus analyzer! To make it more secure, To make it more secure I did not provide any source code.

