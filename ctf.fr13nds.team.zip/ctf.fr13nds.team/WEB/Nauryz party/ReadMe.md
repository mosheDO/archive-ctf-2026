Name: Nauryz party
Value: 0
Description: Invitation generator, just create your own and come to the party.
