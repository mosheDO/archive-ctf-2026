Name: CertifyX
Value: 0
Description: CertifyX prepares certificate data before exporting final documents.
During a review, a critical issue was reported, but the developer dismissed it, claiming nothing sensitive is exposed since users never see the final output.
