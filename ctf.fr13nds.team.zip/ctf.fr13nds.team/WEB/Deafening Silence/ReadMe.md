Name: Deafening Silence
Value: 0
Description: The startup "SecureAccess" has rolled out an innovative, accessibility-first
authentication system. Their lead developer has been bragging on security
forums that the system is immune to all forms of SQL injection:

    "We've thought of everything. The server never returns database errors.
     Response times are completely randomized. There's literally no way to
     extract information from our system, even if you find an injection point.
     The oracle is deaf -- it will never speak back to you."

Prove him wrong. Sometimes, you just have to listen closely.

New instance - http://104.248.82.195:8080/
