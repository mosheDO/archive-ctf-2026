Name: Footgun
Value: 0
Description: The Go standard library is safe by default. Except when it isn't.

