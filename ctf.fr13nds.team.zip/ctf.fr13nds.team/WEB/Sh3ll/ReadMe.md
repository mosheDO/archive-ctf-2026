Name: Sh3ll
Value: 0
Description: HackCity Software Engineers are currently working on creating custom terminal. We invite everyone interested to join the beta test.
