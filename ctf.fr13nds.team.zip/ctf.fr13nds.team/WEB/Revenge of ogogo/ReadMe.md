Name: Revenge of ogogo
Value: 0
Description: I came back for revenge.

No more puny subservices to help you now.

Web: http://revenge-ogogo.ctf.fr13nds.team

Bot: http://revenge-ogogo-admin-bot.ctf.fr13nds.team
