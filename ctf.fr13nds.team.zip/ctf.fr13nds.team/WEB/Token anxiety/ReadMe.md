Name: Token anxiety
Value: 0
Description: I vibe coded this file-upload service, but there is no frontend because I ran out of tokens.

> Credentials: `guest:guest`

> Endpoints: `/login`, `/profile`, `/upload`, `/flag`
