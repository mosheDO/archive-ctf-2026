Name: Arirang
Value: 0
Description: You need to determine the exact location where this photo was taken and mark the location on http://geo.ctf.fr13nds.team with an accuracy of 20 meters to get the flag.

> If the map doesn't load, try refreshing the page, or try using a different browser.
