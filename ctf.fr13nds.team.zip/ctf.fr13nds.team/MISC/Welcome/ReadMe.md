Name: Welcome
Value: 0
Description: Discord: https://discord.gg/vBEFfUyy

UPD: Dont ask for flag in support tickets, its not there
