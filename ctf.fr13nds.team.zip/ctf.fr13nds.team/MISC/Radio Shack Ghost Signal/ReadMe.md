Name: Radio Shack: Ghost Signal
Value: 0
Description: Our monitoring station picked up what appears to be a regular music broadcast. But our analysts suspect something is hidden beneath the surface — a ghost signal, buried where no one would think to look.
