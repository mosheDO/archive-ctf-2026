Name: Radio Shack: Welcome
Value: 0
Description: Welcome to FR13NDS Radio Shack!

We've set up a radio station for you. Tune in and listen carefully.
