Name: Radio Shack: Scrambled
Value: 0
Description: Our field agents intercepted a suspicious radio transmission coming from an
unknown source. The signal appears to be a voice broadcast, but something is
very wrong — our standard audio tools can't even open it.

We've managed to locate their streaming server. 

Your mission: **figure out what's protecting this transmission, strip away
the layers, and extract the hidden message.**

*DID YOU SOLVE WELCOME TASK?!*
